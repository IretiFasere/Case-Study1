﻿# Case-Study1
Ireti Fasere
March 6, 2017

Introduction
This repository is for Case Study1 for SMU Class MSDS 6306-402, Doing Data Science. In this repository, we analyze the data set Country and GDPcleaned.csv.


1. Created a ReadMe file for this repository. The ReadMe file explains the purpose of the project.. Load up a dataset file from the url link provided. Read the dataset to R using the read.csv option.  The two-dataset are Country.csv and GDP.csv. 


3. The clean-up of the dataset removing NA’s and accounting for the numbers of NA’S removed.



4. The cleaned dataset were merged together as the Mergeddata, and sorted in ascending order by GDP


. Analysis on the dataset includes calculating the average GDP rankings for the high-income groups. A graph ggplot of all the Countries GDP was plotted after installing the ggplot2 package on R studio.

The summary of the income group was generated and the quartiles for all the income group was derived.


Conclusion
The analysis shows the high-income group has a greater variance in GDP estimates than any other group, and has a low mean ranking. There are also lower middle income country economies in the higher quartile of the GDP estimates. USA has the highest GDP estimate and ranks number 1.


